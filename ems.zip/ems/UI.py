

import BLL
import multipart

from fastapi import FastAPI , Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
app=FastAPI()
temp=Jinja2Templates(directory="templates")

@app.get('/' , response_class=HTMLResponse)
def root(request: Request):
    objEmp=BLL.Employee()
    data=objEmp.Fetch()
    # print(data)
    return temp.TemplateResponse("home.html", {"request": request , "data": data})

@app.get('/insert', response_class=HTMLResponse )
@app.post('/insert', response_class=HTMLResponse )
async def insert(request: Request):

    if request.method=="POST":
        form_data=  await request.form()
        
        Id=form_data.get("empid")
        name=form_data.get("empname") 
        doj=form_data.get("doj")
        salary=form_data.get("salary" )
        did=form_data.get("did" )
        age=form_data.get("age")
        country=form_data.get("Country" )
        contact=form_data.get("contact")
        print(Id,name)
        objInsert=BLL.Employee(Id,name,doj,salary,did,age,country,contact)
        objInsert.Insert()

    print("Hello")
    return temp.TemplateResponse("insert.html", {"request": request })
                          




# user_input= input('Enter F to fetch data I to insert data U to update Data D to delete Data: ')

# if user_input=='F':
#     objEmp=BLL.Employee()
#     data=objEmp.Fetch()
#     for d in data:
#         print('Empid:',d[0] , 'EmpName:',d[1])
# elif user_input=='I':
#     Id=int(input("Enter ID: "))
#     name=input("Enter name: ")
#     doj=input("Enter DOJ: ")
#     salary=int(input("Enter salary: "))
#     did=int(input("Enter did: "))
#     age=int(input("Enter age: "))
#     country=input("Enter country: ")
#     contact=int(input("Enter contact: "))

#     objInsert=BLL.Employee(Id,name,doj,salary,did,age,country,contact)
#     objInsert.Insert()
# elif user_input=='D':
#     Id=int(input("Enter ID: "))
#     objDelete=BLL.Employee(Id)
#     objDelete.Delete()
# elif user_input=='U':
#     C1=input("Enter Country: ")
#     Id=int(input("Enter Id: "))
#     objUpdate=BLL.Employee(Id , country=C1)
    
#     objUpdate.Update()









    
