import DBAL
class  Employee:
    def __init__(self , empid=0,empname='name',DOJ='nil',salary=100,age=10,did=0,country='none',contact=000):
        self.empid=empid
        self.empname=empname
        self.DOJ=DOJ
        self.salary=salary
        self.age=age
        self.did=did
        self.country=country
        self.contact=contact
    def Fetch(self):
        f=DBAL.FetchData()
        return f
    def Insert(self):
        DBAL.InsertData(self)
    def Delete(self):
        DBAL.DeleteData(self)
    def Update(self ):
        DBAL.UpdateData(self)
