
import pyodbc
def Connection():
    Connection=pyodbc.connect(r'Driver=SQL Server; Server=DESKTOP-HPEJNAD\SQLEXPRESS; Database=PythonBatch')
    cur= Connection.cursor()
    return cur 

def FetchData():
    cursor= Connection()
    cursor.execute('Select * from Employee')
    rows=cursor.fetchall()
    return rows
def InsertData(x):
    cursor= Connection()
    cursor.execute(f"Insert into Employee values({x.empid},'{x.empname}','{x.DOJ}',{x.salary},{x.did},{x.age},'{x.country}',{x.contact})")
    cursor.commit()
def DeleteData(x):
    cursor= Connection()
    cursor.execute(f"Delete from Employee where EmpId={x.empid}")
    cursor.commit()
def UpdateData(x):
    cursor= Connection()
    cursor.execute(f"Update Employee set Country='{x.country}' where EmpId={x.empid}  ")
    cursor.commit()








    
